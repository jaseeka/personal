package com.common.controller;


/**
 * Created by jaseeka
 * Date 2015/11/29
 * Time 17:13
 */
public class BaseController {
}
